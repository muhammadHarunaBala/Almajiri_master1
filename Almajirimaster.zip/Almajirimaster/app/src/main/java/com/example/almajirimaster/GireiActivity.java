package com.example.almajirimaster;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class GireiActivity extends AppCompatActivity implements View.OnClickListener {
    private ImageView btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_girei);
        btn= findViewById(R.id.imageViewg);
        btn.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        if (v==btn){
            startActivity(new Intent(this,SchoolsActivity.class));
        }

    }
}
