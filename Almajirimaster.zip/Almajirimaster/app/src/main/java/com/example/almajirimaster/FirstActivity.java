package com.example.almajirimaster;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ViewFlipper;

public class FirstActivity extends AppCompatActivity implements View.OnClickListener {
    private Button button, about;
    private ViewFlipper viewFlipper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);
        about= findViewById(R.id.button4);

        int images[] = {R.drawable.almajiri1,R.drawable.amajiri2,R.drawable.almajiri3,R.drawable.almajiri4};

        viewFlipper = findViewById(R.id.slid);
        about.setOnClickListener(this);

        for (int i =0; i<images.length;i ++);
      //  slideimages(images[4]);
        slideimages(images[1]);
        slideimages(images[2]);
        slideimages(images[3]);
        slideimages(images[0]);

        //for (int aaaa:images);{
       //     slideimages;
      //  }
        button= findViewById(R.id.schools);
        button.setOnClickListener(this);


    }

    public void  slideimages(int images){
        ImageView imageView = new ImageView(this);
        imageView.setBackgroundResource(images);
        viewFlipper.addView(imageView);
        viewFlipper.setFlipInterval(4000);
        viewFlipper.setAutoStart(true);


        viewFlipper.setInAnimation(this,android.R.anim.slide_in_left);
        viewFlipper.setOutAnimation(this,android.R.anim.slide_out_right);


    }

    @Override
    public void onClick(View v) {
        if (v == button) {
            startActivity(new Intent(this,SchoolsActivity.class));
        }
        else if (v==about){
            startActivity(new Intent(this,AboutActivity.class));
        }




    }
}
