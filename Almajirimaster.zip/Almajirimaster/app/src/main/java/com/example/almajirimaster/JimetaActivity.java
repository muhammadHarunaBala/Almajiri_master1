package com.example.almajirimaster;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class JimetaActivity extends AppCompatActivity implements View.OnClickListener {
    private ImageView btnback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jimeta);
        btnback= findViewById(R.id.imageView);
        btnback.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        if (v==btnback){
            startActivity(new Intent(this,SchoolsActivity.class));
        }

    }
}
