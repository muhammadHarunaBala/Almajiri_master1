package com.example.almajirimaster;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.time.Instant;

public class SchoolsActivity extends AppCompatActivity implements View.OnClickListener {
    private Button yola,jimeta,girei;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schools);


        yola= findViewById(R.id.button);
        jimeta=findViewById(R.id.button2);
        girei=findViewById(R.id.button3);


        yola.setOnClickListener(this);
        jimeta.setOnClickListener(this);
        girei.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v==yola){
            startActivity(new Intent(this,YolaActivity.class));
        }
        else if (v==jimeta){
            startActivity(new Intent(this,JimetaActivity.class));
        }
        else if (v==girei){
            startActivity(new Intent(this,GireiActivity.class));
        }

    }
}
